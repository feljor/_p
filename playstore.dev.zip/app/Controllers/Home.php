<?php namespace App\Controllers;


use App\Models\ScraperModel;
use Config\CustomConfig;

class Home extends BaseController
{
	public function index()
	{
        $scraper = new ScraperModel();
        $title = new CustomConfig();

        $data = [
            'title' => $title->pageTitle,
            'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'paid_apps' => $scraper->TOP_PAID_APPS(),
            'paid_games' => $scraper->TOP_PAID_GAMES(),
            'new_paid_apps' => $scraper->NEW_PAID_APPS(),
            'new_paid_games' => $scraper->NEW_PAID_GAMES(),
            'trending_apps' => $scraper->TRENDING_APPS(),
            'grossing_apps' => $scraper->GROSSING_APPS(),
            'grossing_games' => $scraper->TOP_GROSSING_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS()
        ];

        echo view('part/header', $data);
        echo view('home', $data);
        echo view('part/footer', $data);
	}

	public function detail($appId){

	    $scraper = new ScraperModel();
	    $details = $scraper->APP_DETAIL($appId);
	    $dir = $this->replaceString($details->title);
	    $dev = esc($details->developer, 'url');
        $sourceURL="https://apkpure.com/$dir/$details->appId/download?from=details";

	    $data = [
	        'title' => $details->title.' '.$details->version.' APK Download',
	        'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_GAMES(),
            'trending_apps' => $scraper->TRENDING_APPS(),
	        'app_detail' => $details,
            'similar_apps' => $scraper->SIMILAR_APPS($appId),
            'developer_apps' => $scraper->DEVELOPER_APS($dev),
            'reviews' => $scraper->GET_REVIEWS($appId),
            'downloadLink' => $sourceURL
        ];

        echo view('part/header', $data);
        echo view('detail', $data);
        echo view('part/footer', $data);

    }

    public function categories($catId){

        $scraper = new ScraperModel();
        $categories = $scraper->GET_CATEGORIES_LIST();

        $data = [
            'title' => 'Download APK from '.$catId,
            'category' => $categories,
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS(),
            'category_apps' => $scraper->CATEGORY_APPS($catId)
        ];

        echo view('part/header', $data);
        echo view('category', $data);
        echo view('part/footer', $data);

    }

    public function apps(){

        $scraper = new ScraperModel();

        $data = [
            'title' => 'Download Android APK from SmartPlay',
            'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'paid_apps' => $scraper->TOP_PAID_APPS(),
            'paid_games' => $scraper->TOP_PAID_GAMES(),
            'new_paid_apps' => $scraper->NEW_PAID_APPS(),
            'new_paid_games' => $scraper->NEW_PAID_GAMES(),
            'trending_apps' => $scraper->TRENDING_APPS(),
            'grossing_apps' => $scraper->TOP_FREE_APPS(),
            'grossing_games' => $scraper->TOP_GROSSING_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS()
        ];

        echo view('part/header', $data);
        echo view('apps', $data);
        echo view('part/footer', $data);

    }

    public function games(){

        $scraper = new ScraperModel();

        $data = [
            'title' => 'Download Android APK from SmartPlay',
            'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'paid_apps' => $scraper->TOP_PAID_APPS(),
            'paid_games' => $scraper->TOP_PAID_GAMES(),
            'new_paid_apps' => $scraper->NEW_PAID_APPS(),
            'new_paid_games' => $scraper->NEW_PAID_GAMES(),
            'trending_apps' => $scraper->TRENDING_APPS(),
            'grossing_apps' => $scraper->TOP_FREE_APPS(),
            'grossing_games' => $scraper->TOP_GROSSING_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS()
        ];

        echo view('part/header', $data);
        echo view('apps', $data);
        echo view('part/footer', $data);

    }

    public function developers($developer){

        $scraper = new ScraperModel();
        $dev = esc($developer, 'url');

        $data = [
            'title' => 'Download APK from '.$developer,
            'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS(),
            'developer_apps' => $scraper->DEVELOPER_APS($dev)
        ];

        echo view('part/header', $data);
        echo view('developer', $data);
        echo view('part/footer', $data);
    }

    public function search(){

	    $query = $_POST['q'];
	    $scraper = new ScraperModel();
	    $queries = str_replace(' ', '+', $query);
        $data = [
            'title' => 'Search results for '.$query,
            'category' => $scraper->GET_CATEGORIES_LIST(),
            'popular_apps' => $scraper->TOP_FREE_APPS(),
            'popular_games' => $scraper->TOP_FREE_GAMES(),
            'latest_games' => $scraper->NEW_FREE_GAMES(),
            'latest_apps' => $scraper->NEW_FREE_APPS(),
            'search_results' => $scraper->SEARCH_APPS($queries),
            'query' => $query
        ];

        echo view('part/header', $data);
        echo view('search', $data);
        echo view('part/footer', $data);
    }

    public function downloadLink(){

        $sourceURL="https://apkpure.com/allocine/com.allocine.androidapp/download?from=details%2Fsimilar";

        $scraper = new WebsiteScraper($sourceURL);
        $links = $scraper->getHrefLinks();

        return json_encode($links[41]['url']);
    }

    public function replaceString($phrase){
	    if($phrase){
	        $pace = str_replace(':', '', str_replace(',', '', str_replace('&', '', str_replace('-', '', str_replace('(','', str_replace(')','', str_replace('[', '', str_replace(']','', $phrase))))))));

	        return strtolower(str_replace(' ', '-', $pace));
        }

	    return false;
    }

}
