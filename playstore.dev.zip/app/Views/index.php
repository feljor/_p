<?php getFile("part/header") ?>
<?php getFile("part/home") ?>
<?php getFile("part/footer") ?>